let rosterState = defaultAppState();
let editingClientId = null;
let notesClientId = null;
let editingAll = false;
let rosterSearchTerm = "";
let pendingDischargeClientId = null;

function getInputValue(id) {
  const input = document.getElementById(id);
  if (!input) {
    alert(`Missing input field: ${id}`);
    throw new Error(`Missing input field: ${id}`);
  }
  return input.value.trim();
}

function formatPhoneNumber(value) {
  const digits = String(value || "").replace(/\D/g, "");
  if (digits.length === 10) return `${digits.slice(0, 3)}-${digits.slice(3, 6)}-${digits.slice(6)}`;
  return String(value || "");
}

async function saveRoster() {
  try {
    await saveAppState(rosterState);
    return true;
  } catch (error) {
    console.error("Roster save failed:", error);
    const code = error?.code ? ` (${error.code})` : "";
    alert(`Could not save roster${code}. Your account is signed in, but Firestore rejected the roster update. Ensure the current firestore.rules file is deployed.`);
    return false;
  }
}

function addClient() {
  rosterState.roster = Array.isArray(rosterState.roster)
    ? rosterState.roster.filter(client => client && client !== "temp")
    : [];

  const entryDate = getInputValue("entryDate");

  const client = {
    id: crypto.randomUUID(),
    roomNumber: getInputValue("roomNumber"),
    firstName: getInputValue("firstName"),
    lastName: getInputValue("lastName"),
    clientId: getInputValue("clientId"),
    dob: getInputValue("dob"),
    phone: formatPhoneNumber(getInputValue("phone")),
    address: getInputValue("address"),
    city: getInputValue("city"),
    contact: getInputValue("contact"),
    contactPhone: formatPhoneNumber(getInputValue("contactPhone")),
    entryDate,
    expectedDischargeDate: calculateExitDate(entryDate),
    opocCompleted: false,
    phase2AdmissionDate: "",
    phase: "phase1",
    archived: false,
    archivedAt: "",
    archiveReason: "",
    notes: []
  };

  if (!client.firstName || !client.lastName) {
    alert("Enter at least a first and last name.");
    return;
  }

  rosterState.roster.push(client);
  clearClientForm();
  renderRoster();
  saveRoster();
}

function clearClientForm() {
  [
    "roomNumber", "firstName", "lastName", "clientId", "dob", "phone",
    "address", "city", "contact", "contactPhone", "entryDate"
  ].forEach(id => {
    const input = document.getElementById(id);
    if (input) input.value = "";
  });
}

function calculateExitDate(entryDate) {
  if (!entryDate) return "";

  const [year, month, day] = entryDate.split("-").map(Number);
  const exitDate = new Date(year, month - 1, day);
  exitDate.setMonth(exitDate.getMonth() + 3);

  if (exitDate.getDate() !== day) {
    exitDate.setDate(0);
  }

  return exitDate.toISOString().slice(0, 10);
}

function getDischargeDate(client) {
  return client.expectedDischargeDate || calculateExitDate(client.entryDate);
}

function calculateDaysRemainingForClient(client) {
  const dischargeDate = getDischargeDate(client);
  if (!dischargeDate) return "";

  const today = new Date();
  today.setHours(0, 0, 0, 0);

  const exit = new Date(dischargeDate + "T00:00:00");
  const diffDays = Math.ceil((exit.getTime() - today.getTime()) / (1000 * 60 * 60 * 24));

  if (diffDays < 0) return "Due / Past";
  if (diffDays === 0) return "Today";
  if (diffDays === 1) return "1 day";
  return `${diffDays} days`;
}

function getDaysSinceAdmission(client) {
  if (!client.entryDate) return 0;

  const entry = new Date(client.entryDate + "T00:00:00");
  const today = new Date();

  entry.setHours(0, 0, 0, 0);
  today.setHours(0, 0, 0, 0);

  return Math.floor((today.getTime() - entry.getTime()) / (1000 * 60 * 60 * 24));
}

function getOPOCStatus(client) {
  const days = getDaysSinceAdmission(client);

  if (client.opocCompleted) {
    return `
      <label class="opoc-cell opoc-complete">
        <input type="checkbox" checked onchange="toggleOPOC('${client.id}', this.checked)" />
        <span>Complete</span>
      </label>
    `;
  }

  if (!client.entryDate) {
    return `
      <label class="opoc-cell">
        <input type="checkbox" onchange="toggleOPOC('${client.id}', this.checked)" />
      </label>
    `;
  }

  if (days >= 50) {
    return `
      <label class="opoc-cell opoc-overdue">
        <input type="checkbox" onchange="toggleOPOC('${client.id}', this.checked)" />
        <span>OVERDUE</span>
      </label>
    `;
  }

  if (days >= 40) {
    return `
      <label class="opoc-cell opoc-due">
        <input type="checkbox" onchange="toggleOPOC('${client.id}', this.checked)" />
        <span>OPOC Due</span>
      </label>
    `;
  }

  return `
    <label class="opoc-cell">
      <input type="checkbox" onchange="toggleOPOC('${client.id}', this.checked)" />
    </label>
  `;
}

function toggleOPOC(clientId, checked) {
  const client = rosterState.roster.find(item => item.id === clientId);
  if (!client) return;

  client.opocCompleted = checked;
  renderRoster();
  saveRoster();
}

function getDischargeClass(client) {
  const dischargeDate = getDischargeDate(client);
  if (!dischargeDate) return "discharge-missing";

  const today = new Date();
  today.setHours(0, 0, 0, 0);

  const exit = new Date(dischargeDate + "T00:00:00");
  const diffDays = Math.ceil((exit.getTime() - today.getTime()) / (1000 * 60 * 60 * 24));

  if (diffDays < 0) return "discharge-overdue";
  if (diffDays <= 14) return "discharge-warning";
  return "discharge-ok";
}

function getMissingAdmissionFields(client) {
  const missing = [];

  if (!client.roomNumber) missing.push("Room");
  if (!client.clientId) missing.push("Client ID");
  if (!client.dob) missing.push("DOB");
  if (!client.phone) missing.push("Phone");
  if (!client.entryDate) missing.push("Entry");
  if (!getDischargeDate(client)) missing.push("Discharge");

  return missing;
}

function getCompletionBadge(client) {
  const missing = getMissingAdmissionFields(client);

  if (!missing.length) {
    return `<span class="status active">Complete</span>`;
  }

  return `<span class="status warning-status">Missing: ${escapeHtml(missing.join(", "))}</span>`;
}

function formatDate(value) {
  if (!value) return "";

  const date = new Date(value + "T00:00:00");
  return date.toLocaleDateString("en-CA", {
    year: "numeric",
    month: "short",
    day: "2-digit"
  });
}

function formatDateTime(value) {
  if (!value) return "";

  const date = new Date(value);
  return date.toLocaleString("en-CA", {
    year: "numeric",
    month: "short",
    day: "2-digit",
    hour: "numeric",
    minute: "2-digit"
  });
}

function startInlineEdit(clientId) {
  if (editingAll) return;
  openEditResidentModal(clientId);
}

function cancelInlineEdit() {
  editingClientId = null;
  renderRoster();
}

function startEditAll() {
  editingClientId = null;
  editingAll = true;
  updateEditAllButtons();
  renderRoster();
}

function cancelEditAll() {
  editingAll = false;
  updateEditAllButtons();
  renderRoster();
}

function updateEditAllButtons() {
  const editAllBtn = document.getElementById("editAllBtn");
  const saveAllBtn = document.getElementById("saveAllBtn");
  const cancelAllBtn = document.getElementById("cancelAllBtn");

  if (!editAllBtn || !saveAllBtn || !cancelAllBtn) return;

  editAllBtn.classList.toggle("hidden", editingAll);
  saveAllBtn.classList.toggle("hidden", !editingAll);
  cancelAllBtn.classList.toggle("hidden", !editingAll);
  document.body.classList.toggle("roster-edit-all-active", editingAll);
}

function saveAllEdits() {
  const roster = Array.isArray(rosterState.roster)
    ? rosterState.roster.filter(client => client && client !== "temp" && !client.archived)
    : [];

  roster.forEach(client => saveClientFromEditInputs(client.id, false));

  editingAll = false;
  editingClientId = null;
  updateEditAllButtons();
  renderRoster();
  saveRoster();
}

function saveClientFromEditInputs(clientId, shouldRender = true) {
  const client = rosterState.roster.find(item => item.id === clientId);
  if (!client) return;

  client.roomNumber = getInputValue(`editRoomNumber-${clientId}`);
  client.firstName = getInputValue(`editFirstName-${clientId}`);
  client.lastName = getInputValue(`editLastName-${clientId}`);
  client.clientId = getInputValue(`editClientId-${clientId}`);
  client.dob = getInputValue(`editDob-${clientId}`);
  client.phone = formatPhoneNumber(getInputValue(`editPhone-${clientId}`));
  client.expectedDischargeDate = getInputValue(`editDischargeDate-${clientId}`);

  const opocInput = document.getElementById(`editOpoc-${clientId}`);
  if (opocInput) {
    client.opocCompleted = opocInput.checked;
  }

  if ((client.phase || "phase1") === "phase1") {
    client.address = getInputValue(`editAddress-${clientId}`);
    client.city = getInputValue(`editCity-${clientId}`);
    client.contact = getInputValue(`editContact-${clientId}`);
    client.contactPhone = formatPhoneNumber(getInputValue(`editContactPhone-${clientId}`));
    client.entryDate = getInputValue(`editEntryDate-${clientId}`);
  } else {
    client.phase2AdmissionDate = getInputValue(`editPhase2AdmissionDate-${clientId}`);
  }

  if (shouldRender) {
    editingClientId = null;
    renderRoster();
    saveRoster();
  }
}

function saveInlineEdit(clientId) {
  saveClientFromEditInputs(clientId, true);
}


function residentModalField(label, id, value, type = "text", full = false) {
  return `
    <label class="kbrh-modal-field ${full ? "kbrh-modal-field-full" : ""}">
      <span>${escapeHtml(label)}</span>
      <input id="${id}" type="${type}" value="${escapeAttribute(value || "")}" />
    </label>
  `;
}

function residentModalSection(title, description = "") {
  return `
    <div class="kbrh-modal-section-heading kbrh-modal-field-full">
      <h3>${escapeHtml(title)}</h3>
      ${description ? `<p>${escapeHtml(description)}</p>` : ""}
    </div>
  `;
}

function openEditResidentModal(clientId) {
  const client = rosterState.roster.find(item => item && item.id === clientId);
  const modal = document.getElementById("editResidentModal");
  const fields = document.getElementById("editResidentFields");
  if (!client || !modal || !fields) return;

  editingClientId = clientId;
  const phase = client.phase || "phase1";
  const fullName = `${client.firstName || ""} ${client.lastName || ""}`.trim();
  document.getElementById("editResidentModalSubtitle").textContent = fullName || "Update this resident's information.";

  let html = residentModalSection("Resident Information");
  html += residentModalField("Room #", "modalEditRoomNumber", client.roomNumber);
  html += residentModalField("Client ID", "modalEditClientId", client.clientId);
  html += residentModalField("First Name", "modalEditFirstName", client.firstName);
  html += residentModalField("Last Name", "modalEditLastName", client.lastName);
  html += residentModalField("Date of Birth", "modalEditDob", client.dob, "date");
  html += residentModalField("Phone", "modalEditPhone", client.phone);

  if (phase === "phase1") {
    html += residentModalSection("Contact and Address");
    html += residentModalField("Address", "modalEditAddress", client.address, "text", true);
    html += residentModalField("City", "modalEditCity", client.city);
    html += residentModalField("Emergency Contact", "modalEditContact", client.contact);
    html += residentModalField("Contact Phone", "modalEditContactPhone", client.contactPhone);
    html += residentModalSection("Admission");
    html += residentModalField("Entry Date", "modalEditEntryDate", client.entryDate, "date");
  } else {
    html += residentModalSection("Admission");
    html += residentModalField("Phase 2 Entry Date", "modalEditPhase2AdmissionDate", client.phase2AdmissionDate, "date");
  }

  html += residentModalField("Expected Discharge Date", "modalEditDischargeDate", getDischargeDate(client), "date");
  html += `
    <label class="kbrh-modal-check">
      <input id="modalEditOpoc" type="checkbox" ${client.opocCompleted ? "checked" : ""} />
      <span>OPOC completed</span>
    </label>
  `;
  fields.innerHTML = html;

  modal.classList.remove("hidden");
  document.body.classList.add("kbrh-modal-open");
  requestAnimationFrame(() => document.getElementById("modalEditFirstName")?.focus());
}

function closeEditResidentModal() {
  document.getElementById("editResidentModal")?.classList.add("hidden");
  document.body.classList.remove("kbrh-modal-open");
  editingClientId = null;
}

function saveEditResidentModal(event) {
  event?.preventDefault();
  const client = rosterState.roster.find(item => item && item.id === editingClientId);
  if (!client) return;

  const value = id => document.getElementById(id)?.value.trim() || "";
  const firstName = value("modalEditFirstName");
  const lastName = value("modalEditLastName");
  if (!firstName || !lastName) {
    alert("First and last name are required.");
    return;
  }

  client.roomNumber = value("modalEditRoomNumber");
  client.clientId = value("modalEditClientId");
  client.firstName = firstName;
  client.lastName = lastName;
  client.dob = value("modalEditDob");
  client.phone = formatPhoneNumber(value("modalEditPhone"));
  client.expectedDischargeDate = value("modalEditDischargeDate");
  client.opocCompleted = Boolean(document.getElementById("modalEditOpoc")?.checked);

  if ((client.phase || "phase1") === "phase1") {
    client.address = value("modalEditAddress");
    client.city = value("modalEditCity");
    client.contact = value("modalEditContact");
    client.contactPhone = formatPhoneNumber(value("modalEditContactPhone"));
    client.entryDate = value("modalEditEntryDate");
  } else {
    client.phase2AdmissionDate = value("modalEditPhase2AdmissionDate");
  }

  closeEditResidentModal();
  renderRoster();
  saveRoster();
}

function handleRosterAction(clientId, action) {
  if (!action) return;

  if (action === "edit") openEditResidentModal(clientId);
  if (action === "phase2") moveToPhase(clientId, "phase2");
  if (action === "phase1") moveToPhase(clientId, "phase1");
  if (action === "waitlist") moveBackToWaitlist(clientId);
  if (action === "archive") archiveClient(clientId);
  if (action === "restore") restoreClient(clientId);
  if (action === "delete") deleteArchivedClient(clientId);
}

let selectedRosterActionClientId = null;

function openRosterActionsModal(clientId) {
  const client = rosterState.roster.find(item => item.id === clientId);
  if (!client) return;

  selectedRosterActionClientId = clientId;
  const name = `${client.firstName || ""} ${client.lastName || ""}`.trim() || "Selected client";
  const nameElement = document.getElementById("rosterActionsName");
  const actionList = document.getElementById("rosterActionList");

  if (nameElement) nameElement.textContent = name;
  if (actionList) {
    const isArchived = Boolean(client.archived);
    const phase = client.phase || "phase1";

    actionList.innerHTML = isArchived
      ? `
        <button type="button" data-roster-action="restore">Restore</button>
        <button type="button" class="danger" data-roster-action="delete">Delete Permanently</button>
      `
      : `
        <button type="button" data-roster-action="edit">Edit</button>
        <button type="button" data-roster-action="${phase === "phase1" ? "phase2" : "phase1"}">Move to ${phase === "phase1" ? "Phase 2" : "Phase 1"}</button>
        <button type="button" data-roster-action="waitlist">Move back to Waitlist</button>
        <button type="button" data-roster-action="archive">Archive / Discharge</button>
      `;

    actionList.querySelectorAll("[data-roster-action]").forEach(button => {
      button.addEventListener("click", () => {
        const action = button.dataset.rosterAction;
        closeRosterActionsModal();
        handleRosterAction(clientId, action);
      });
    });
  }

  document.getElementById("rosterActionsModal")?.classList.remove("hidden");
}

function closeRosterActionsModal() {
  document.getElementById("rosterActionsModal")?.classList.add("hidden");
  selectedRosterActionClientId = null;
}


function moveBackToWaitlist(clientId) {
  const client = rosterState.roster.find(item => item.id === clientId);
  if (!client) return;

  if (!confirm(`Move ${client.firstName} ${client.lastName} back to the waitlist?`)) return;

  rosterState.waitlist = Array.isArray(rosterState.waitlist)
    ? rosterState.waitlist.filter(item => item && item !== "temp")
    : [];

  const priorWaitlistRecord = rosterState.waitlist.find(item => {
    if (!item || !item.dateApplied) return false;
    if (client.waitlistSourceId && item.id === client.waitlistSourceId) return true;

    const sameName = String(item.firstName || "").trim().toLowerCase() === String(client.firstName || "").trim().toLowerCase()
      && String(item.lastName || "").trim().toLowerCase() === String(client.lastName || "").trim().toLowerCase();
    const itemPhone = String(item.contact || "").replace(/\D/g, "");
    const clientPhone = String(client.phone || "").replace(/\D/g, "");
    const samePhone = itemPhone && clientPhone && itemPhone === clientPhone;

    return sameName && (samePhone || !itemPhone || !clientPhone);
  });

  const originalApplicationDate = client.originalApplicationDate
    || priorWaitlistRecord?.originalApplicationDate
    || priorWaitlistRecord?.dateApplied
    || "";

  const transferNote = {
    id: crypto.randomUUID(),
    text: `Moved back to the waitlist from the current roster on ${new Date().toLocaleDateString("en-CA")}.`,
    createdAt: new Date().toISOString()
  };

  const existingNotes = Array.isArray(client.notes)
    ? client.notes.map(note => ({
        id: note.id || crypto.randomUUID(),
        text: note.text || "",
        createdAt: note.createdAt || new Date().toISOString()
      })).filter(note => note.text)
    : [];

  rosterState.waitlist.push({
    id: crypto.randomUUID(),
    lastName: client.lastName || "",
    firstName: client.firstName || "",
    contact: formatPhoneNumber(client.phone || ""),
    status: "Returned from Roster",
    city: client.city || "",
    dateApplied: originalApplicationDate,
    originalApplicationDate,
    archived: false,
    archivedAt: "",
    archiveReason: "",
    callPriority: "normal",
    notes: [transferNote, ...existingNotes],
    callInHistory: []
  });

  client.archived = true;
  client.archivedAt = new Date().toISOString();
  client.archiveReason = "Moved back to Waitlist";
  client.notes = Array.isArray(client.notes) ? client.notes : [];
  client.notes.unshift({
    id: crypto.randomUUID(),
    author: "System",
    text: `Moved back to the waitlist on ${new Date().toLocaleDateString("en-CA")}.`,
    createdAt: new Date().toISOString()
  });

  editingClientId = null;
  editingAll = false;
  updateEditAllButtons();
  renderRoster();
  saveRoster();
}

function moveToPhase(clientId, phase) {
  const client = rosterState.roster.find(item => item.id === clientId);
  if (!client) return;

  client.phase = phase;
  appendPersonActivity(client,"Phase",phase==="phase2"?"Moved to Phase 2":"Moved to Phase 1","");

  if (phase === "phase2") {
    client.phase2AdmissionDate = new Date().toISOString().slice(0, 10);
  }

  renderRoster();
  saveRoster();
}

async function archiveClient(clientId) {
  const client = rosterState.roster.find(item => item.id === clientId);
  if (!client) return;

  pendingDischargeClientId = clientId;
  const name = `${client.firstName || ""} ${client.lastName || ""}`.trim();
  document.getElementById("dischargeResidentName").textContent = name;
  document.getElementById("dischargeOutcome").value = "";
  document.getElementById("dischargeNotes").value = "";
  document.getElementById("dischargeModal").classList.remove("hidden");
  document.body.classList.add("kbrh-modal-open");
}

function closeDischargeModal() {
  pendingDischargeClientId = null;
  document.getElementById("dischargeModal")?.classList.add("hidden");
  document.body.classList.remove("kbrh-modal-open");
}

async function confirmDischarge() {
  const clientId = pendingDischargeClientId;
  const localClient = rosterState.roster.find(item => item.id === clientId);
  if (!localClient) return closeDischargeModal();

  const select = document.getElementById("dischargeOutcome");
  const outcomeCode = select.value;
  const outcomeLabel = select.options[select.selectedIndex]?.textContent?.trim() || "";
  const dischargeNotes = document.getElementById("dischargeNotes").value.trim();
  if (!outcomeCode) { alert("Select a discharge reason."); return; }

  if (!confirm(`Archive ${localClient.firstName} ${localClient.lastName}?\n\nReason: ${outcomeLabel}\n\nThis removes the resident from the active roster and keeps the record in Archived Residents.`)) return;

  const user = auth.currentUser;
  if (!user) { alert("Your login session has expired. Please sign in again before archiving a resident."); return; }

  let identity = { uid:user.uid||"", email:user.email||"", name:user.email||"Staff User" };
  if (typeof getCurrentStaffIdentity === "function") {
    try { identity = await getCurrentStaffIdentity(); }
    catch (error) { console.warn("Staff profile lookup failed during archive; using authenticated identity.", error); }
  }

  const archivedAt = new Date().toISOString();
  const archiveReason = outcomeLabel;
  const appRef = APP_DOC_REF();

  try {
    const latestSnap = await appRef.get({ source:"server" });
    if (!latestSnap.exists) throw new Error("Shared KBRH application record was not found.");

    const latest = normalizeAppState(latestSnap.data());
    const roster = Array.isArray(latest.roster) ? latest.roster.map(r => ({...r})) : [];
    const index = roster.findIndex(item => item && item.id === clientId);
    if (index < 0) throw new Error("Resident was not found in the current shared roster.");

    const resident = { ...roster[index] };
    resident.archived = true;
    resident.archivedAt = archivedAt;
    resident.archiveReason = archiveReason;
    resident.dischargeOutcomeCode = outcomeCode;
    resident.dischargeOutcomeLabel = outcomeLabel;
    resident.dischargeNotes = dischargeNotes;
    resident.archivedBy = identity.name || identity.email || "Staff User";
    resident.archivedByUid = identity.uid || "";
    resident.archivedByEmail = identity.email || "";
    appendPersonActivity(resident,"Archive","Resident archived / discharged",[archiveReason, dischargeNotes].filter(Boolean).join(" — "),identity,archivedAt);
    resident.notes = Array.isArray(resident.notes) ? [...resident.notes] : [];
    resident.notes.unshift({
      id: crypto.randomUUID(), author: resident.archivedBy, authorUid: resident.archivedByUid, authorEmail: resident.archivedByEmail,
      text: `Archived from roster on ${new Date(archivedAt).toLocaleDateString("en-CA")}. Reason: ${archiveReason}.${dischargeNotes ? ` Notes: ${dischargeNotes}` : ""}`, createdAt: archivedAt
    });
    roster[index] = resident;

    const cleanRoster = normalizeAppState({ roster }).roster;
    await appRef.update({ roster: cleanRoster, updatedAt: archivedAt });

    const verifySnap = await appRef.get({ source:"server" });
    if (!verifySnap.exists) throw new Error("Archive save could not be verified.");
    const verified = normalizeAppState(verifySnap.data());
    const verifiedClient = verified.roster.find(item => item.id === clientId);
    if (!verifiedClient || verifiedClient.archived !== true) throw new Error("Firestore returned the resident as active after the archive save.");

    rosterState = verified; KBRH_LAST_STATE = normalizeAppState(verified);
    closeDischargeModal(); renderRoster();
    if (typeof writeAuditEntry === "function") {
      writeAuditEntry([`Archived resident: ${verifiedClient.firstName || ""} ${verifiedClient.lastName || ""} — ${archiveReason}`.trim()], identity)
        .catch(error => console.warn("Archive audit entry failed, but the resident archive was saved.", error));
    }
  } catch (error) {
    console.error("Resident archive failed:", error);
    const code = error?.code ? ` [${error.code}]` : "";
    const message = error?.message ? `\n\n${error.message}` : "";
    alert(`Could not archive resident${code}. The resident was NOT removed from the active roster.${message}`);
    try { const latest = await appRef.get({ source:"server" }); if (latest.exists) rosterState = normalizeAppState(latest.data()); } catch (_) {}
    renderRoster();
  }
}

function restoreClient(clientId) {
  const client = rosterState.roster.find(item => item.id === clientId);
  if (!client) return;

  if (!confirm(`Restore ${client.firstName} ${client.lastName} to the active roster?`)) return;

  client.archived = false;
  appendPersonActivity(client,"Restore","Resident restored to active roster","");
  client.archivedAt = "";
  client.archiveReason = "";
  client.dischargeOutcomeCode = "";
  client.dischargeOutcomeLabel = "";
  client.dischargeNotes = "";

  client.notes = Array.isArray(client.notes) ? client.notes : [];
  client.notes.unshift({
    id: crypto.randomUUID(),
    author: "System",
    text: `Restored to active roster on ${new Date().toLocaleDateString("en-CA")}.`,
    createdAt: new Date().toISOString()
  });

  renderRoster();
  saveRoster();
}

function deleteArchivedClient(clientId) {
  const client = rosterState.roster.find(item => item.id === clientId);
  if (!client) return;

  if (!client.archived) {
    alert("Only archived roster records can be permanently deleted.");
    return;
  }

  if (!confirm(`Permanently delete archived record for ${client.firstName} ${client.lastName}? This cannot be undone.`)) return;

  rosterState.roster = rosterState.roster.filter(item => item.id !== clientId);
  renderRoster();
  saveRoster();
}

function openNotes(clientId) {
  const client = rosterState.roster.find(item => item.id === clientId);
  if (!client) return;

  notesClientId = clientId;

  document.getElementById("notesModalTitle").textContent =
    `Notes — ${client.firstName || ""} ${client.lastName || ""}`.trim();

  document.getElementById("noteAuthor").value = typeof currentStaffName === "function" ? currentStaffName() : "";
  document.getElementById("noteAuthor").readOnly = true;
  document.getElementById("newNoteText").value = "";

  renderNotesModal(client);
  document.getElementById("notesModal").classList.remove("hidden");
}

function closeNotesModal() {
  notesClientId = null;
  document.getElementById("notesModal").classList.add("hidden");
}

function addClientNote() {
  const client = rosterState.roster.find(item => item.id === notesClientId);
  if (!client) return;

  const author = typeof currentStaffName === "function" ? currentStaffName() : getInputValue("noteAuthor");
  const text = getInputValue("newNoteText");

  if (!author) {
    alert("Please enter your name.");
    return;
  }

  if (!text) {
    alert("Enter a note first.");
    return;
  }

  client.notes = Array.isArray(client.notes) ? client.notes : [];

  client.notes.unshift({
    id: crypto.randomUUID(),
    author,
    text,
    createdAt: new Date().toISOString()
  });
  appendPersonActivity(client,"Note","Resident note added",text);

  document.getElementById("noteAuthor").value = "";
  document.getElementById("newNoteText").value = "";

  renderNotesModal(client);
  renderRoster();
  saveRoster();
}

function deleteClientNote(noteId) {
  const client = rosterState.roster.find(item => item.id === notesClientId);
  if (!client) return;

  if (!confirm("Delete this note?")) return;

  client.notes = Array.isArray(client.notes)
    ? client.notes.filter(note => note.id !== noteId)
    : [];

  renderNotesModal(client);
  renderRoster();
  saveRoster();
}

function renderNotesModal(client) {
  const list = document.getElementById("notesList");
  if (!list) return;

  const notes = Array.isArray(client.notes) ? client.notes : [];

  list.innerHTML = notes.length
    ? notes.map(note => `
        <li class="note-item">
          <div>
            <div><strong>${escapeHtml(note.author || "Unknown")}</strong></div>
            <div>• ${escapeHtml(note.text)}</div>
            <small>${escapeHtml(formatDateTime(note.createdAt))}</small>
          </div>
          <button type="button" class="danger" onclick="deleteClientNote('${note.id}')">Delete</button>
        </li>
      `).join("")
    : `<li class="empty">No notes yet.</li>`;
}

function handleRosterSearch(value) {
  rosterSearchTerm = String(value || "").toLowerCase().trim();
  renderRoster();
}

function matchesRosterSearch(client) {
  if (!rosterSearchTerm) return true;

  const haystack = [
    client.roomNumber,
    client.firstName,
    client.lastName,
    client.clientId,
    client.phone,
    client.city
  ].join(" ").toLowerCase();

  return haystack.includes(rosterSearchTerm);
}

function renderRoster() {
  updateEditAllButtons();
  updatePhase1ResidentCount();
  renderPhase1Roster();
  renderPhase2Roster();
  renderArchivedRoster();
}

function updatePhase1ResidentCount() {
  const capacity = 18;
  const count = Array.isArray(rosterState.roster)
    ? rosterState.roster.filter(client =>
        client &&
        client !== "temp" &&
        !client.archived &&
        (client.phase || "phase1") === "phase1"
      ).length
    : 0;

  const countElement = document.getElementById("phase1ResidentCount");
  const detailElement = document.getElementById("phase1CapacityDetail");
  const card = document.getElementById("phase1ResidentCard");
  if (!countElement || !detailElement || !card) return;

  const available = Math.max(capacity - count, 0);
  countElement.textContent = String(count);
  detailElement.textContent = count >= capacity
    ? "FULL"
    : `${available} bed${available === 1 ? "" : "s"} available`;

  card.classList.remove("capacity-open", "capacity-near", "capacity-full");
  if (count >= capacity) card.classList.add("capacity-full");
  else if (count === capacity - 1) card.classList.add("capacity-near");
  else card.classList.add("capacity-open");
}

function getPhaseClients(phase) {
  return Array.isArray(rosterState.roster)
    ? rosterState.roster
        .filter(client =>
          client &&
          client !== "temp" &&
          !client.archived &&
          (client.phase || "phase1") === phase &&
          matchesRosterSearch(client)
        )
        .sort((a, b) => {
          const aDate = a.entryDate || "9999-12-31";
          const bDate = b.entryDate || "9999-12-31";
          return aDate.localeCompare(bDate);
        })
    : [];
}

function getArchivedClients() {
  return Array.isArray(rosterState.roster)
    ? rosterState.roster
        .filter(client => client && client !== "temp" && client.archived && matchesRosterSearch(client))
        .sort((a, b) => String(b.archivedAt || "").localeCompare(String(a.archivedAt || "")))
    : [];
}

function renderPhase1Roster() {
  const body = document.getElementById("rosterBody");
  const compactBody = document.getElementById("compactRosterBody");
  if (!body) return;

  const roster = getPhaseClients("phase1");

  body.innerHTML = roster.length
    ? roster.map(client => renderActiveRosterRow(client, "phase1")).join("")
    : `<tr><td colspan="17" class="empty">No Phase 1 clients.</td></tr>`;

  if (compactBody) {
    compactBody.innerHTML = roster.length
      ? roster.map(client => renderCompactRosterRow(client)).join("")
      : `<tr><td colspan="6" class="empty">No Phase 1 clients.</td></tr>`;
  }
}

function renderPhase2Roster() {
  const body = document.getElementById("phase2RosterBody");
  const compactBody = document.getElementById("compactPhase2RosterBody");
  if (!body) return;

  const roster = getPhaseClients("phase2");

  body.innerHTML = roster.length
    ? roster.map(client => renderActiveRosterRow(client, "phase2")).join("")
    : `<tr><td colspan="12" class="empty">No Phase 2 clients.</td></tr>`;

  if (compactBody) {
    compactBody.innerHTML = roster.length
      ? roster.map(client => renderCompactRosterRow(client)).join("")
      : `<tr><td colspan="6" class="empty">No Phase 2 clients.</td></tr>`;
  }
}

function renderCompactRosterRow(client) {
  const daysRemaining = calculateDaysRemainingForClient(client);
  const dischargeClass = getDischargeClass(client);
  const fullName = `${client.firstName || ""} ${client.lastName || ""}`.trim() || "Unnamed resident";

  return `
    <tr>
      <td class="compact-room-cell">${escapeHtml(client.roomNumber || "—")}</td>
      <td class="compact-name-cell"><strong>${escapeHtml(fullName)}</strong><span>Client ID: ${escapeHtml(client.clientId || "—")}</span></td>
      <td class="${dischargeClass}">${escapeHtml(daysRemaining)}</td>
      <td>${getCompletionBadge(client)}</td>
      <td><button type="button" class="secondary compact-info-button" onclick="openResidentInfoModal('${client.id}')">Display Info</button></td>
      <td><button type="button" class="actions-button" onclick="openRosterActionsModal('${client.id}')">Actions</button></td>
    </tr>
  `;
}

function residentInfoItem(label, value, full = false) {
  return `
    <div class="resident-info-item ${full ? "resident-info-item-full" : ""}">
      <span>${escapeHtml(label)}</span>
      <strong>${escapeHtml(value || "—")}</strong>
    </div>
  `;
}

function openResidentInfoModal(clientId) {
  const client = rosterState.roster.find(item => item && item.id === clientId);
  const modal = document.getElementById("residentInfoModal");
  const body = document.getElementById("residentInfoBody");
  if (!client || !modal || !body) return;

  const phase = client.phase || "phase1";
  const fullName = `${client.firstName || ""} ${client.lastName || ""}`.trim() || "Resident";
  const dischargeDate = getDischargeDate(client);
  const daysRemaining = calculateDaysRemainingForClient(client);
  const noteCount = Array.isArray(client.notes) ? client.notes.length : 0;
  document.getElementById("residentInfoModalSubtitle").textContent = fullName;

  let html = `<section class="resident-info-section"><h3>Resident</h3><div class="resident-info-grid">`;
  html += residentInfoItem("Room #", client.roomNumber);
  html += residentInfoItem("Client ID", client.clientId);
  html += residentInfoItem("First Name", client.firstName);
  html += residentInfoItem("Last Name", client.lastName);
  html += residentInfoItem("Date of Birth", formatDate(client.dob));
  html += residentInfoItem("Phone", client.phone);
  html += `</div></section>`;

  if (phase === "phase1") {
    html += `<section class="resident-info-section"><h3>Contact and Address</h3><div class="resident-info-grid">`;
    html += residentInfoItem("Address", client.address, true);
    html += residentInfoItem("City", client.city);
    html += residentInfoItem("Emergency Contact", client.contact);
    html += residentInfoItem("Contact Phone", client.contactPhone);
    html += `</div></section>`;
  }

  html += `<section class="resident-info-section"><h3>Admission</h3><div class="resident-info-grid">`;
  html += residentInfoItem(phase === "phase1" ? "Entry Date" : "Phase 2 Entry Date", formatDate(phase === "phase1" ? client.entryDate : client.phase2AdmissionDate));
  html += residentInfoItem("Expected Discharge", formatDate(dischargeDate));
  html += residentInfoItem("Days Remaining", daysRemaining);
  html += residentInfoItem("OPOC", client.opocCompleted ? "Complete" : "Incomplete");
  html += residentInfoItem("Admission Status", client.admissionCompleted ? "Complete" : "Incomplete");
  html += residentInfoItem("Notes", `${noteCount} note${noteCount === 1 ? "" : "s"}`);
  html += `</div></section>`;
  const activity=[...normalizeActivityHistory(client.activityHistory),...(Array.isArray(client.notes)?client.notes.map(note=>({id:`note-${note.id}`,summary:"Note",detail:note.text||"",staffName:note.author||"Unknown",createdAt:note.createdAt||""})):[])].filter(x=>x.createdAt).sort((a,b)=>String(b.createdAt).localeCompare(String(a.createdAt)));
  html += `<section class="resident-info-section"><h3>Activity History</h3><div class="person-activity-list">${activity.length?activity.map(entry=>`<article class="person-activity-item"><div><strong>${escapeHtml(entry.summary||entry.type||"Activity")}</strong><span>${escapeHtml(entry.detail||"")}</span></div><small>${escapeHtml(formatDateTime(entry.createdAt))} · ${escapeHtml(entry.staffName||"System")}</small></article>`).join(""):`<p class="empty">No activity recorded yet.</p>`}</div></section>`;

  body.innerHTML = html;
  modal.classList.remove("hidden");
  document.body.classList.add("kbrh-modal-open");
  requestAnimationFrame(() => document.getElementById("closeResidentInfoModalBtn")?.focus());
}

function closeResidentInfoModal() {
  document.getElementById("residentInfoModal")?.classList.add("hidden");
  document.body.classList.remove("kbrh-modal-open");
}

function renderActiveRosterRow(client, phase) {
  const isEditing = editingAll;
  const dischargeDate = getDischargeDate(client);
  const daysRemaining = calculateDaysRemainingForClient(client);
  const noteCount = Array.isArray(client.notes) ? client.notes.length : 0;
  const dischargeClass = getDischargeClass(client);

  if (isEditing) {
    if (phase === "phase1") {
      return `
        <tr class="editing-row">
          <td><input id="editRoomNumber-${client.id}" value="${escapeAttribute(client.roomNumber)}" /></td>
          <td><input id="editFirstName-${client.id}" value="${escapeAttribute(client.firstName)}" /></td>
          <td><input id="editLastName-${client.id}" value="${escapeAttribute(client.lastName)}" /></td>
          <td><input id="editClientId-${client.id}" value="${escapeAttribute(client.clientId)}" /></td>
          <td><input id="editDob-${client.id}" type="date" value="${escapeAttribute(client.dob)}" /></td>
          <td class="phone-cell"><input id="editPhone-${client.id}" value="${escapeAttribute(client.phone)}" /></td>
          <td><input id="editAddress-${client.id}" value="${escapeAttribute(client.address)}" /></td>
          <td><input id="editCity-${client.id}" value="${escapeAttribute(client.city)}" /></td>
          <td><input id="editContact-${client.id}" value="${escapeAttribute(client.contact)}" /></td>
          <td class="phone-cell"><input id="editContactPhone-${client.id}" value="${escapeAttribute(client.contactPhone)}" /></td>
          <td><input id="editEntryDate-${client.id}" type="date" value="${escapeAttribute(client.entryDate)}" /></td>
          <td><input id="editDischargeDate-${client.id}" type="date" value="${escapeAttribute(dischargeDate)}" /></td>
          <td class="${dischargeClass}">${escapeHtml(daysRemaining)}</td>
          <td><input id="editOpoc-${client.id}" type="checkbox" ${client.opocCompleted ? "checked" : ""} /></td>
          <td>${getCompletionBadge(client)}</td>
          <td><a href="#" onclick="openNotes('${client.id}'); return false;">Notes (${noteCount})</a></td>
          <td>
            ${
              editingAll
                ? `<span class="empty">Use Save All above</span>`
                : `
                  <button type="button" class="success" onclick="saveInlineEdit('${client.id}')">Save</button>
                  <button type="button" class="secondary" onclick="cancelInlineEdit()">Cancel</button>
                `
            }
          </td>
        </tr>
      `;
    }

    return `
      <tr class="editing-row">
        <td><input id="editRoomNumber-${client.id}" value="${escapeAttribute(client.roomNumber)}" /></td>
        <td><input id="editFirstName-${client.id}" value="${escapeAttribute(client.firstName)}" /></td>
        <td><input id="editLastName-${client.id}" value="${escapeAttribute(client.lastName)}" /></td>
        <td><input id="editClientId-${client.id}" value="${escapeAttribute(client.clientId)}" /></td>
        <td><input id="editDob-${client.id}" type="date" value="${escapeAttribute(client.dob)}" /></td>
        <td class="phone-cell"><input id="editPhone-${client.id}" value="${escapeAttribute(client.phone)}" /></td>
        <td><input id="editPhase2AdmissionDate-${client.id}" type="date" value="${escapeAttribute(client.phase2AdmissionDate)}" /></td>
        <td><input id="editDischargeDate-${client.id}" type="date" value="${escapeAttribute(dischargeDate)}" /></td>
        <td class="${dischargeClass}">${escapeHtml(daysRemaining)}</td>
        <td>${getCompletionBadge(client)}</td>
        <td><a href="#" onclick="openNotes('${client.id}'); return false;">Notes (${noteCount})</a></td>
        <td>
          ${
            editingAll
              ? `<span class="empty">Use Save All above</span>`
              : `
                <button type="button" class="success" onclick="saveInlineEdit('${client.id}')">Save</button>
                <button type="button" class="secondary" onclick="cancelInlineEdit()">Cancel</button>
              `
          }
        </td>
      </tr>
    `;
  }

  if (phase === "phase1") {
    return `
      <tr>
        <td>${escapeHtml(client.roomNumber)}</td>
        <td>${escapeHtml(client.firstName)}</td>
        <td>${escapeHtml(client.lastName)}</td>
        <td>${escapeHtml(client.clientId)}</td>
        <td>${escapeHtml(formatDate(client.dob))}</td>
        <td class="phone-cell">${escapeHtml(client.phone)}</td>
        <td>${escapeHtml(client.address)}</td>
        <td>${escapeHtml(client.city)}</td>
        <td>${escapeHtml(client.contact)}</td>
        <td class="phone-cell">${escapeHtml(client.contactPhone)}</td>
        <td>${escapeHtml(formatDate(client.entryDate))}</td>
        <td>${escapeHtml(formatDate(dischargeDate))}</td>
        <td class="${dischargeClass}">${escapeHtml(daysRemaining)}</td>
        <td>${getOPOCStatus(client)}</td>
        <td>${getCompletionBadge(client)}</td>
        <td><a href="#" onclick="openNotes('${client.id}'); return false;">Notes (${noteCount})</a></td>
        <td>
          <button type="button" class="actions-button" onclick="openRosterActionsModal('${client.id}')">Actions</button>
        </td>
      </tr>
    `;
  }

  return `
    <tr>
      <td>${escapeHtml(client.roomNumber)}</td>
      <td>${escapeHtml(client.firstName)}</td>
      <td>${escapeHtml(client.lastName)}</td>
      <td>${escapeHtml(client.clientId)}</td>
      <td>${escapeHtml(formatDate(client.dob))}</td>
      <td class="phone-cell">${escapeHtml(client.phone)}</td>
      <td>${escapeHtml(formatDate(client.phase2AdmissionDate))}</td>
      <td>${escapeHtml(formatDate(dischargeDate))}</td>
      <td class="${dischargeClass}">${escapeHtml(daysRemaining)}</td>
      <td>${getCompletionBadge(client)}</td>
      <td><a href="#" onclick="openNotes('${client.id}'); return false;">Notes (${noteCount})</a></td>
      <td>
        <button type="button" class="actions-button" onclick="openRosterActionsModal('${client.id}')">Actions</button>
      </td>
    </tr>
  `;
}

function renderArchivedRoster() {
  const body = document.getElementById("archivedRosterBody");
  if (!body) return;

  const archived = getArchivedClients();

  body.innerHTML = archived.length
    ? archived.map(client => {
        const noteCount = Array.isArray(client.notes) ? client.notes.length : 0;

        return `
          <tr>
            <td>${escapeHtml(client.roomNumber)}</td>
            <td>${escapeHtml(client.firstName)}</td>
            <td>${escapeHtml(client.lastName)}</td>
            <td>${escapeHtml(client.clientId)}</td>
            <td>${escapeHtml(client.phone)}</td>
            <td>${escapeHtml(formatDate(client.entryDate))}</td>
            <td>${escapeHtml(formatDate(getDischargeDate(client)))}</td>
            <td>${escapeHtml(formatDateTime(client.archivedAt))}</td>
            <td>${escapeHtml(client.archiveReason)}</td>
            <td><a href="#" onclick="openNotes('${client.id}'); return false;">Notes (${noteCount})</a></td>
            <td>
              <button type="button" class="actions-button" onclick="openRosterActionsModal('${client.id}')">Actions</button>
            </td>
          </tr>
        `;
      }).join("")
    : `<tr><td colspan="11" class="empty">No archived roster records.</td></tr>`;
}

function escapeHtml(value) {
  return String(value || "").replace(/[&<>"']/g, char => ({
    "&": "&amp;",
    "<": "&lt;",
    ">": "&gt;",
    '"': "&quot;",
    "'": "&#039;"
  }[char]));
}

function escapeAttribute(value) {
  return escapeHtml(value);
}

document.addEventListener("DOMContentLoaded", () => {
  document.getElementById("closeResidentInfoModalBtn")?.addEventListener("click", closeResidentInfoModal);
  document.getElementById("closeResidentInfoModalFooterBtn")?.addEventListener("click", closeResidentInfoModal);
  document.getElementById("residentInfoModal")?.addEventListener("mousedown", event => {
    if (event.target.id === "residentInfoModal") closeResidentInfoModal();
  });

  document.getElementById("closeRosterActionsModalBtn")?.addEventListener("click", closeRosterActionsModal);
  document.getElementById("cancelRosterActionsModalBtn")?.addEventListener("click", closeRosterActionsModal);
  document.getElementById("rosterActionsModal")?.addEventListener("mousedown", event => {
    if (event.target.id === "rosterActionsModal") closeRosterActionsModal();
  });

  document.addEventListener("keydown", event => {
    if (event.key !== "Escape") return;
    if (!document.getElementById("residentInfoModal")?.classList.contains("hidden")) {
      closeResidentInfoModal();
      return;
    }
    if (!document.getElementById("rosterActionsModal")?.classList.contains("hidden")) {
      closeRosterActionsModal();
    }
  });
});

auth.onAuthStateChanged(user => {
  if (!user) return;

  listenToAppState(nextState => {
    rosterState = nextState;

    rosterState.roster = Array.isArray(rosterState.roster)
      ? rosterState.roster.filter(client => client && client !== "temp")
      : [];

    rosterState.roster.forEach(client => {
      client.roomNumber = client.roomNumber || "";
      client.phase = client.phase || "phase1";
      client.notes = Array.isArray(client.notes) ? client.notes : [];
      client.phase2AdmissionDate = client.phase2AdmissionDate || "";
      client.expectedDischargeDate = client.expectedDischargeDate || calculateExitDate(client.entryDate);
      client.opocCompleted = client.opocCompleted || false;
      client.archived = client.archived || false;
      client.archivedAt = client.archivedAt || "";
      client.archiveReason = client.archiveReason || "";
      client.phone = formatPhoneNumber(client.phone);
      client.contactPhone = formatPhoneNumber(client.contactPhone);
    });

    renderRoster();
  });
});


/* v3.3 roster viewport and column visibility controls */
(function initializeRosterDisplayControls() {
  const STORAGE_KEY = "kbrhRosterVisibleColumnsV33";
  const defaultVisibility = {
    dob: true,
    phone: true,
    address: true,
    city: true,
    contact: true,
    contactPhone: true,
    entryDate: true,
    dischargeDate: true,
    daysRemaining: true,
    opoc: true,
    admissionStatus: true,
    notes: true
  };

  function readVisibility() {
    try {
      return { ...defaultVisibility, ...JSON.parse(localStorage.getItem(STORAGE_KEY) || "{}") };
    } catch (error) {
      return { ...defaultVisibility };
    }
  }

  function saveVisibility(visibility) {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(visibility));
  }

  function applyVisibility(visibility) {
    Object.keys(defaultVisibility).forEach(column => {
      document.body.classList.toggle(`hide-roster-${column}`, visibility[column] === false);
    });

    document.querySelectorAll("[data-roster-column]").forEach(input => {
      input.checked = visibility[input.dataset.rosterColumn] !== false;
    });
  }

  function setup() {
    const panel = document.getElementById("rosterColumnPanel");
    const toggleButton = document.getElementById("toggleRosterColumnsBtn");
    const showAllButton = document.getElementById("showAllRosterColumnsBtn");
    if (!panel || !toggleButton) return;

    let visibility = readVisibility();
    applyVisibility(visibility);

    toggleButton.addEventListener("click", () => {
      const opening = panel.classList.contains("hidden");
      panel.classList.toggle("hidden", !opening);
      toggleButton.setAttribute("aria-expanded", String(opening));
      toggleButton.textContent = opening ? "Close Columns" : "Choose Columns";
    });

    document.querySelectorAll("[data-roster-column]").forEach(input => {
      input.addEventListener("change", () => {
        visibility[input.dataset.rosterColumn] = input.checked;
        saveVisibility(visibility);
        applyVisibility(visibility);
      });
    });

    showAllButton?.addEventListener("click", () => {
      visibility = { ...defaultVisibility };
      saveVisibility(visibility);
      applyVisibility(visibility);
    });
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", setup, { once: true });
  } else {
    setup();
  }
})();


document.addEventListener("DOMContentLoaded", () => {
  document.getElementById("editResidentForm")?.addEventListener("submit", saveEditResidentModal);
  document.getElementById("closeEditResidentModalBtn")?.addEventListener("click", closeEditResidentModal);
  document.getElementById("cancelEditResidentModalBtn")?.addEventListener("click", closeEditResidentModal);
  document.getElementById("editResidentModal")?.addEventListener("click", event => {
    if (event.target?.id === "editResidentModal") closeEditResidentModal();
  });
  document.addEventListener("keydown", event => {
    if (event.key === "Escape" && !document.getElementById("editResidentModal")?.classList.contains("hidden")) {
      closeEditResidentModal();
    }
  });
});


document.addEventListener("DOMContentLoaded", () => {
  document.getElementById("closeDischargeModalBtn")?.addEventListener("click", closeDischargeModal);
  document.getElementById("cancelDischargeModalBtn")?.addEventListener("click", closeDischargeModal);
  document.getElementById("confirmDischargeBtn")?.addEventListener("click", confirmDischarge);
  document.getElementById("dischargeModal")?.addEventListener("mousedown", e => { if (e.target.id === "dischargeModal") closeDischargeModal(); });
});
